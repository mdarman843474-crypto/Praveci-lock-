package com.pindnslock

import android.app.job.JobParameters
import android.app.job.JobService

/**
 * Teen job yahan chalte hain (alag thread par):
 *  - RelockScheduler.JOB_ID               : unlock window khatam, sab wapas lock
 *  - DnsGuard.JOB_PERIODIC / JOB_TRIGGER  : Private DNS ki nigrani
 */
class RelockJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        if (params == null) return false
        val jobId = params.jobId
        val ctx = applicationContext
        Thread {
            try {
                if (jobId != DnsGuard.JOB_PERIODIC && jobId != DnsGuard.JOB_TRIGGER) {
                    DnsLock.relock(ctx) // unlock ka time khatam: rokein wapas lagao
                }
                DnsGuard.runOnce(ctx) // Private DNS saved host par laao + nigrani dobara lagao
            } catch (e: Exception) {
                // agli baar (app khulne par / 15 minute baad) phir try hoga
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = params?.jobId == RelockScheduler.JOB_ID
}
