package com.pindnslock

import java.text.DateFormat
import java.util.Date

/** App me dikhne wala saara text ek jagah (Hinglish). Logic wali files me text nahi rakhte. */
object Messages {

    // ---- DNS lock ke kaam ke natije ----

    fun lockResult(r: LockResult): String = when (r) {
        is LockResult.Ok ->
            if (r.checkSkipped)
                "Lock ho gaya (Private DNS, factory reset, PIN DNS Lock ka update band), par host ka check is network par fail hua tha. Internet na chale to 10 minute ke liye unlock karke Private DNS Off karo"
            else
                "Lock ho gaya: Private DNS (kisi bhi raaste se badla to wapas lag jayega), factory reset aur PIN DNS Lock ka update band hain. Dusre APK bina unlock ke install hote hain"
        is LockResult.Fail -> failText(r)
    }

    fun unlockResult(r: LockResult, minutes: Int): String = when (r) {
        is LockResult.Ok ->
            "$minutes minute ke liye unlock hai: PIN DNS Lock ka update ho sakta hai. Private DNS badaloge to lock hote hi saved host wapas lag jayega. Factory reset band rahega"
        is LockResult.Fail -> failText(r)
    }

    fun updateResult(r: LockResult, minutes: Int): String = when (r) {
        is LockResult.Ok ->
            "$minutes minute ke liye PIN DNS Lock ka update khula hai. Private DNS lock waisa hi hai. Dusre APK hamesha install hote hain"
        is LockResult.Fail -> failText(r)
    }

    fun removeResult(r: LockResult): String = when (r) {
        is LockResult.Ok -> "Device Owner hat gaya, sab lock khul gaye. Ab app uninstall kar sakte ho"
        is LockResult.Fail -> failText(r)
    }

    private fun failText(f: LockResult.Fail): String = when (f.reason) {
        LockResult.Reason.NOT_OWNER -> "App abhi Device Owner nahi hai. Pehle adb se Device Owner banao"
        LockResult.Reason.BAD_HOST -> "Host ka naam sahi nahi hai"
        LockResult.Reason.HOST_NOT_SERVING ->
            "Android ka host check is network par fail hua. Settings me Private DNS ke andar ye host khud daalo, ya adb se WRITE_SECURE_SETTINGS permission do, phir dobara lock karo"
        LockResult.Reason.SET_FAILED -> "Private DNS set nahi hua (code ${f.detail})"
        LockResult.Reason.DNS_MISMATCH ->
            "Private DNS expected jaisa nahi dikha (Android me abhi: ${f.detail}). Lock nahi lagaya"
        LockResult.Reason.VERIFY_FAILED -> "Lock verify nahi hua (Android me abhi: ${f.detail}). Dobara try karo"
        LockResult.Reason.RELOCK_NOT_SCHEDULED -> "Auto-lock schedule nahi ho paya, isliye unlock nahi kiya"
        LockResult.Reason.STILL_LOCKED -> "Unlock nahi ho paya (restriction abhi bhi lagi hai)"
        LockResult.Reason.STILL_OWNER -> "Device Owner abhi hata nahi, dobara try karo"
    }

    // ---- PIN ----

    const val PIN_ENTER = "12 digit ka PIN dalo"
    const val PIN_SET_DONE = "PIN set ho gaya. Ab DNS host dalo aur lock karo."
    const val PIN_CHANGED = "PIN badal gaya. Ab naye PIN se kaam hoga"
    const val DEBUG_COPIED = "Debug text copy ho gaya. Chat me paste karo"

    fun pinIssue(issue: PinIssue): String = when (issue) {
        PinIssue.BAD_LENGTH -> "PIN poore 12 digit ka hona chahiye"
        PinIssue.TOO_SIMPLE -> "PIN bahut aasaan hai, alag-alag digits rakho"
        PinIssue.MISMATCH -> "Dono PIN same nahi hain"
        PinIssue.OLD_BAD_LENGTH -> "Purana PIN 12 digit ka hona chahiye"
        PinIssue.SAME_AS_OLD -> "Naya PIN purane jaisa hi hai, alag PIN rakho"
    }

    /** Galat PIN / lockout ka text. PIN sahi ho to null. */
    fun pinFailure(r: PinResult): String? = when (r) {
        PinResult.Ok -> null
        is PinResult.Wrong -> wrongPin(r.attemptsLeft)
        is PinResult.Locked -> pinLocked(r.seconds)
    }

    fun wrongPin(attemptsLeft: Int): String = "Galat PIN. $attemptsLeft koshish baaki"

    fun pinLocked(seconds: Long): String = "Bahut galat koshish. $seconds second baad try karo"

    fun errorText(e: Exception): String = "Error: ${e.message}"

    // ---- Upar ka status box ----

    private fun pageBlockText(p: PageBlockState): String = when (p) {
        PageBlockState.RUNNING -> "chalu"
        PageBlockState.ENABLED_NOT_RUNNING -> "ON hai par chal nahi rahi (app khud dobara chalu karegi)"
        PageBlockState.OFF -> "band (Settings → Accessibility me ON karo, ya adb permission do)"
    }

    private fun updateText(s: DeviceStatus): String = when {
        s.updateUntil > System.currentTimeMillis() ->
            "khula hai, " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(s.updateUntil)) + " tak"
        s.updateLocked -> "BLOCKED (update ke liye 'PIN DNS Lock update ke liye 10 minute' dabao)"
        else -> "khula hai"
    }

    private fun batteryText(b: BatteryState): String = when (b) {
        BatteryState.OK -> "No restrictions"
        BatteryState.OPTIMIZED -> "Optimized (chalega, par 'No restrictions' behtar)"
        BatteryState.RESTRICTED -> "RESTRICTED: nigrani ruk sakti hai, Settings me 'No restrictions' karo"
    }

    fun status(s: DeviceStatus): String {
        val sb = StringBuilder()
        sb.append("Device Owner: ").append(if (s.owner) "haan" else "nahi").append('\n')
        sb.append("Private DNS abhi: ").append(s.dns)
        if (s.owner) {
            val state = when {
                s.locked -> "LOCKED"
                s.unlockUntil > 0 -> "unlocked, " +
                    DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(s.unlockUntil)) + " tak"
                else -> "abhi lock nahi kiya"
            }
            sb.append('\n').append("Settings me Private DNS: ").append(state)
            sb.append('\n').append("Private DNS nigrani: ").append(if (s.guardOn) "chalu" else "band")
            sb.append('\n').append("Turant wapas lagane wali service: ").append(if (s.fastGuard) "chalu" else "band")
            sb.append('\n').append("Settings pages band (Private DNS, Search, Additional settings, Factory reset): ").append(pageBlockText(s.pageBlock))
            sb.append('\n').append("Seedha likhne ki permission: ").append(if (s.directWrite) "haan" else "nahi (adb se WRITE_SECURE_SETTINGS do)")
            sb.append('\n').append("PIN DNS Lock ka update: ").append(updateText(s))
            sb.append('\n').append("Factory reset: ").append(if (s.resetBlocked) "BLOCKED" else "khula hai")
            sb.append('\n').append("App info (uninstall / force stop / data clear): ").append(if (s.appLocked) "BLOCKED" else "khula hai")
            sb.append('\n').append("Battery usage: ").append(batteryText(s.battery))
            sb.append('\n').append("(Debug ke liye is box ko dabake rakho)")
        }
        return sb.toString()
    }
}
