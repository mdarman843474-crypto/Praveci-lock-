package com.pindnslock

import android.content.Context
import android.os.Build

/**
 * "App info" ki rok, sirf is app ke liye (baaki apps par koi asar nahi):
 *  - Uninstall band (setUninstallBlocked)
 *  - Force stop aur Clear data / cache band (setUserControlDisabledPackages, Android 11+)
 * Device Owner hone tak lagi rehti hai, sirf "Device Owner hatao" se hat'ti hai.
 */
object AppLock {
    /** Kabhi exception nahi fenkta: na lagi to isApplied() false dega. */
    fun apply(c: Context) {
        val d = Admin.dpm(c)
        val a = Admin.component(c)
        runCatching { d.setUninstallBlocked(a, c.packageName, true) }
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching { d.setUserControlDisabledPackages(a, listOf(c.packageName)) }
        }
    }

    fun remove(c: Context) {
        val d = Admin.dpm(c)
        val a = Admin.component(c)
        runCatching { d.setUninstallBlocked(a, c.packageName, false) }
        if (Build.VERSION.SDK_INT >= 30) {
            runCatching { d.setUserControlDisabledPackages(a, emptyList()) }
        }
    }

    /** Read-back: rok sach me lagi hai? (Device Owner na ho to false) */
    fun isApplied(c: Context): Boolean {
        val d = Admin.dpm(c)
        val a = Admin.component(c)
        val uninstallBlocked = runCatching { d.isUninstallBlocked(a, c.packageName) }.getOrDefault(false)
        val controlDisabled = Build.VERSION.SDK_INT < 30 ||
            runCatching { d.getUserControlDisabledPackages(a).contains(c.packageName) }.getOrDefault(false)
        return uninstallBlocked && controlDisabled
    }
}
