package com.pindnslock

import android.app.ActivityManager
import android.content.Context
import android.os.PowerManager
import android.provider.Settings

/** Sirf padhne wala hissa: system abhi kis haal me hai. Yahan kuch badalta nahi. */
object DnsState {
    private const val KEY_MODE = "private_dns_mode"
    private const val KEY_HOST = "private_dns_specifier"
    private const val MODE_HOSTNAME = "hostname"

    fun isOwner(c: Context): Boolean = Admin.dpm(c).isDeviceOwnerApp(c.packageName)

    /** Private DNS lock laga hai? (poore lock ka mukhya nishan) */
    fun isLocked(c: Context): Boolean = Restrictions.isSet(c, Restrictions.DNS)

    /** PIN DNS Lock ka update abhi band hai? (lock laga ho aur 10 minute ki update khidki khuli na ho) */
    fun isUpdateLocked(c: Context): Boolean = isOwner(c) && isLocked(c) && !LockStore.updateOpen(c)

    fun isResetBlocked(c: Context): Boolean = Restrictions.isSet(c, Restrictions.RESET)

    /** App info ki rok (uninstall / force stop / clear data) lagi hai? */
    fun isAppLocked(c: Context): Boolean = AppLock.isApplied(c)

    /** Android is app ko background me chalne dega? (Lock nahi kar sakte, sirf dekh sakte hain.) */
    fun battery(c: Context): BatteryState {
        val am = c.getSystemService(ActivityManager::class.java)
        val pm = c.getSystemService(PowerManager::class.java)
        return when {
            am.isBackgroundRestricted -> BatteryState.RESTRICTED
            !pm.isIgnoringBatteryOptimizations(c.packageName) -> BatteryState.OPTIMIZED
            else -> BatteryState.OK
        }
    }

    /** What Android itself reports right now (read-back check). */
    fun currentDns(c: Context): String {
        val mode = Settings.Global.getString(c.contentResolver, KEY_MODE) ?: "off"
        val host = Settings.Global.getString(c.contentResolver, KEY_HOST) ?: ""
        return if (mode == MODE_HOSTNAME) "hostname ($host)" else mode
    }

    /** Android me abhi hostname mode aur yehi host set hai? */
    fun isHostActive(c: Context, host: String): Boolean {
        val mode = Settings.Global.getString(c.contentResolver, KEY_MODE)
        val cur = Settings.Global.getString(c.contentResolver, KEY_HOST)
        return mode == MODE_HOSTNAME && cur?.trim()?.lowercase() == host
    }
}
