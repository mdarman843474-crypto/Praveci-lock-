package com.pindnslock

import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * "Mera Settings": phone ke asli Settings pages ke shortcuts (Wi-Fi, Bluetooth, Mobile networks, ...).
 * Har row system ka asli page kholti hai, isliye saare features waise hi kaam karte hain.
 * Private DNS, Additional settings, Factory reset, Developer options aur Settings search yahan nahi hain.
 * Ye isi app ka hissa hai, isliye Device Owner aur uninstall protection isi par laagu hain.
 */
class SettingsHomeActivity : Activity() {

    private class Tile(val title: String, val color: Int, val summary: String?, val intents: List<Intent>)

    private lateinit var content: LinearLayout
    private var dark = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actionBar?.hide()
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(if (dark) Color.BLACK else Color.parseColor("#F2F2F7"))
            addView(content)
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render() // summary (Wi-Fi / Bluetooth On-Off) har baar taza
    }

    private fun render() {
        content.removeAllViews()
        val title = label("Settings", 32f, true, titleColor())
        content.addView(title, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(20) })

        card(
            listOf(
                Tile("Wi-Fi", BLUE, wifiSummary(), listOf(Intent(Settings.ACTION_WIFI_SETTINGS))),
                Tile("Bluetooth", BLUE, bluetoothSummary(), listOf(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))),
                Tile(
                    "Mobile networks", GREEN, null,
                    listOf(Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS), Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))
                ),
                Tile(
                    "Portable hotspot", BLUE, null,
                    listOf(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"))
                )
            )
        )
        card(
            listOf(
                Tile("Fingerprints, face data, and screen lock", PURPLE, null, listOf(Intent(Settings.ACTION_SECURITY_SETTINGS))),
                Tile(
                    "Safety and emergency", ORANGE, null,
                    listOf(Intent("android.settings.SAFETY_CENTER"), Intent(Settings.ACTION_PRIVACY_SETTINGS))
                ),
                Tile("Privacy protection", BLUE, null, listOf(Intent(Settings.ACTION_PRIVACY_SETTINGS))),
                Tile(
                    "Apps", BLUE, null,
                    listOf(Intent(Settings.ACTION_APPLICATION_SETTINGS), Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS))
                )
            )
        )
        card(
            listOf(
                Tile("Display", AMBER, null, listOf(Intent(Settings.ACTION_DISPLAY_SETTINGS))),
                Tile("Sound and vibration", RED, null, listOf(Intent(Settings.ACTION_SOUND_SETTINGS))),
                Tile("Battery", GREEN, null, listOf(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))),
                Tile("Storage", GREY, null, listOf(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))),
                Tile("Location", BLUE, null, listOf(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))),
                Tile("Accounts and sync", BLUE, null, listOf(Intent(Settings.ACTION_SYNC_SETTINGS))),
                Tile("About phone", GREY, null, listOf(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)))
            )
        )

        val note = label(
            "Private DNS, Additional settings, Factory reset aur Settings search yahan nahi hain. " +
                "Wo PIN DNS Lock me PIN se hi khulte hain.",
            12f, false, mutedColor()
        )
        content.addView(note, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
    }

    private fun card(tiles: List<Tile>) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(if (dark) Color.parseColor("#262626") else Color.WHITE)
                cornerRadius = dp(20).toFloat()
            }
        }
        for (t in tiles) card.addView(row(t))
        content.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(16) })
    }

    private fun row(t: Tile): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true
            setOnClickListener { open(t) }
        }
        val icon = TextView(this).apply {
            text = t.title.take(1)
            gravity = Gravity.CENTER
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(t.color)
                cornerRadius = dp(10).toFloat()
            }
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(16) })

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(t.title, 17f, false, titleColor()))
        val summary = t.summary
        if (!summary.isNullOrEmpty()) texts.addView(label(summary, 13f, false, mutedColor()))
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))

        row.addView(label("\u203A", 22f, false, mutedColor()))
        return row
    }

    /** Pehla intent jo khul jaye wahi chalta hai. Kuch na khule to batata hai. */
    private fun open(t: Tile) {
        for (i in t.intents) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // agla tareeka try karo
            }
        }
        Toast.makeText(this, t.title + " ka page is phone par nahi khula", Toast.LENGTH_SHORT).show()
    }

    private fun wifiSummary(): String? = try {
        if (applicationContext.getSystemService(WifiManager::class.java).isWifiEnabled) "On" else "Off"
    } catch (e: Exception) {
        null
    }

    private fun bluetoothSummary(): String? = try {
        if (getSystemService(BluetoothManager::class.java).adapter.isEnabled) "On" else "Off"
    } catch (e: Exception) {
        null
    }

    private fun label(s: String, sp: Float, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun titleColor(): Int = if (dark) Color.WHITE else Color.parseColor("#1A1A1A")

    private fun mutedColor(): Int = if (dark) Color.parseColor("#9A9A9A") else Color.parseColor("#6F6F6F")

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private companion object {
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        val BLUE = Color.parseColor("#2F7BFF")
        val GREEN = Color.parseColor("#27C463")
        val PURPLE = Color.parseColor("#7B6CF6")
        val ORANGE = Color.parseColor("#F2541B")
        val AMBER = Color.parseColor("#F5A623")
        val RED = Color.parseColor("#E5484D")
        val GREY = Color.parseColor("#8E8E93")
    }
}
