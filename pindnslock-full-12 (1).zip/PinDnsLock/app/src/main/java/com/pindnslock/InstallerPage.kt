package com.pindnslock

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Package installer ka wo screen jahan PIN DNS Lock install / update ho raha ho (sirf English).
 * Dusre apps ke installer screens par is app ka naam nahi hota, isliye wo kabhi nahi rukte.
 * APP_NAME strings.xml ke app_name ke barabar rakho.
 */
object InstallerPage {
    const val APP_NAME = "PIN DNS Lock"

    fun isShownIn(root: AccessibilityNodeInfo): Boolean =
        !root.findAccessibilityNodeInfosByText(APP_NAME).isNullOrEmpty()
}
