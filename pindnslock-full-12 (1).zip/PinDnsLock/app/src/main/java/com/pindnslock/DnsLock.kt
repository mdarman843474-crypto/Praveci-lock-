package com.pindnslock

import android.app.admin.DevicePolicyManager
import android.content.Context

/**
 * Private DNS lock via Device Owner:
 *  - setGlobalPrivateDnsModeSpecifiedHost  -> forces the DNS host
 *  - Restrictions                          -> Private DNS badalna aur factory reset band
 *  - AppLock                               -> App info: uninstall / force stop / clear data band
 *  - DnsGuard                              -> Private DNS kisi aur raaste se badle to saved host wapas lagata hai
 *
 * Yahan sirf kaam ka flow hai. Baaki hisse alag files me hain:
 *  DnsState (system abhi kya dikha raha hai), Restrictions (kaun si rok kab lagti hai),
 *  LockStore (yaad rakhna), RelockScheduler (auto-relock timer), Messages (screen ka text).
 * Har kaam pehle Device Owner check karta hai aur badlav ke baad read-back verify karta hai.
 */
object DnsLock {
    private val HOST_REGEX = Regex("^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")

    private fun fail(reason: LockResult.Reason, detail: String = "") = LockResult.Fail(reason, detail)

    /** Condition thodi der me sach ho jaye to true (system ko badlav apply karne ka time do). Background thread se hi chalao. */
    private fun waitFor(tries: Int = 10, delayMs: Long = 200L, cond: () -> Boolean): Boolean {
        for (i in 0 until tries) {
            if (cond()) return true
            try {
                Thread.sleep(delayMs)
            } catch (e: InterruptedException) {
                return cond()
            }
        }
        return cond()
    }

    /** Blocking (network check + intezaar) - background thread se chalao. */
    fun lock(c: Context, host: String): LockResult {
        if (!DnsState.isOwner(c)) return fail(LockResult.Reason.NOT_OWNER)

        val h = host.trim().lowercase()
        if (!HOST_REGEX.matches(h)) return fail(LockResult.Reason.BAD_HOST)

        val wasLocked = DnsState.isLocked(c)

        // 1) Host set karo (pehle Device Owner API; Android ka check fail ho aur adb permission mili ho to seedha likhte hain)
        val hs = DnsWriter.setHost(c, h)
        var checkSkipped = hs.direct
        if (hs.code != DevicePolicyManager.PRIVATE_DNS_SET_NO_ERROR) {
            if (DnsState.isHostActive(c, h)) {
                // Host Settings me pehle se set hai: Android ka check chhod ke bas usi ko lock karo
                checkSkipped = true
            } else if (hs.code == DevicePolicyManager.PRIVATE_DNS_SET_ERROR_HOST_NOT_SERVING) {
                return fail(LockResult.Reason.HOST_NOT_SERVING)
            } else {
                return fail(LockResult.Reason.SET_FAILED, hs.code.toString())
            }
        }

        // 2) Rokein lagane SE PEHLE read-back: Android sach me yehi host dikha raha hai?
        if (!waitFor { DnsState.isHostActive(c, h) }) {
            return fail(LockResult.Reason.DNS_MISMATCH, DnsState.currentDns(c))
        }

        // 3) Rokein lagao: Private DNS badalna, factory reset, aur App info (uninstall / force stop / clear data)
        LockStore.clearUpdateWindow(c) // poora lock: update ki khidki (agar khuli thi) bhi band
        Restrictions.clearLegacy(c) // purane version ki "sab APK install band" wali rok hatao
        Restrictions.add(c, Restrictions.ALL)
        AppLock.apply(c)

        // 4) Lagne ke BAAD read-back: sab lagi? aur host abhi bhi wahi hai?
        val allOn = waitFor { Restrictions.missing(c, Restrictions.ALL).isEmpty() && AppLock.isApplied(c) }
        if (!allOn || !DnsState.isHostActive(c, h)) {
            val missing = Restrictions.missing(c, Restrictions.ALL).map { it.label }.toMutableList()
            if (!AppLock.isApplied(c)) missing.add("App info")
            if (!wasLocked) {
                Restrictions.clear(c, Restrictions.ALL)
                AppLock.remove(c)
            }
            val note = if (missing.isEmpty()) "" else "; nahi lage: " + missing.joinToString(", ")
            return fail(LockResult.Reason.VERIFY_FAILED, DnsState.currentDns(c) + note)
        }

        LockStore.saveLocked(c, h)
        RelockScheduler.cancel(c)
        DnsGuard.ensureScheduled(c) // Private DNS badalte hi wapas lagane wali nigrani
        PageBlock.ensure(c) // Settings me Private DNS page rokne wali service
        return LockResult.Ok(checkSkipped)
    }

    /**
     * "10 minute unlock": Private DNS khulta hai (aur PIN DNS Lock ka update bhi), factory reset band rehta hai.
     * Blocking (thoda intezaar) - background thread se chalao.
     */
    fun unlock(c: Context, minutes: Int): LockResult {
        if (!DnsState.isOwner(c)) return fail(LockResult.Reason.NOT_OWNER)

        // Pehle auto-relock schedule karo. Ye na ho paye to unlock hi nahi karte, warna lock hamesha khula reh jayega
        if (!RelockScheduler.schedule(c, minutes)) return fail(LockResult.Reason.RELOCK_NOT_SCHEDULED)

        Restrictions.clear(c, Restrictions.ON_LOCK)

        // Read-back: Private DNS ki rok sach me hati? Nahi hati to adhoora unlock chhodne ki jagah poora wapas lock
        if (!waitFor { !DnsState.isLocked(c) }) {
            Restrictions.add(c, Restrictions.ON_LOCK)
            RelockScheduler.cancel(c)
            return fail(LockResult.Reason.STILL_LOCKED)
        }

        LockStore.setUnlockUntil(c, System.currentTimeMillis() + minutes * 60_000L)
        return LockResult.Ok()
    }

    /**
     * "PIN DNS Lock update ke liye 10 minute": is app ka update installer par band nahi hota (PageBlockService rokti hai).
     * Private DNS lock waisa hi rehta hai. Dusre apps ke APK ko is khidki ki zarurat nahi, wo hamesha install hote hain.
     */
    fun allowUpdate(c: Context, minutes: Int): LockResult {
        if (!DnsState.isOwner(c)) return fail(LockResult.Reason.NOT_OWNER)
        LockStore.setUpdateUntil(c, System.currentTimeMillis() + minutes * 60_000L)
        return LockResult.Ok()
    }

    fun relock(c: Context) {
        if (!DnsState.isOwner(c)) return
        Restrictions.add(c, Restrictions.ALL)
        Restrictions.clearLegacy(c)
        AppLock.apply(c)
        // Read-back: rok sach me lagi tabhi unlock window band maano (nahi to agli baar phir try hoga)
        if (DnsState.isLocked(c)) LockStore.clearUnlock(c)
    }

    fun relockIfExpired(c: Context) {
        val until = LockStore.unlockUntil(c)
        if (until != 0L && System.currentTimeMillis() >= until) relock(c)
    }

    /** Purane version ne jo "sab APK install band" wali rok lagayi thi use hatao, taaki dusre APK bina unlock ke install hon. */
    fun dropLegacyInstallBlock(c: Context) {
        if (DnsState.isOwner(c)) Restrictions.clearLegacy(c)
    }

    /** App khulte hi: lock laga ho to poora set pakka karo aur nigrani chalu karo (purane version se update ke baad bhi). */
    fun enforceIfLocked(c: Context) {
        if (!DnsState.isOwner(c) || !DnsState.isLocked(c)) return
        Restrictions.add(c, Restrictions.ALL)
        AppLock.apply(c)
        DnsGuard.kick(c)
    }

    fun removeOwner(c: Context): LockResult {
        if (!DnsState.isOwner(c)) return fail(LockResult.Reason.NOT_OWNER)

        RelockScheduler.cancel(c)
        DnsGuard.cancel(c)
        Restrictions.clear(c, Restrictions.ALL)
        Restrictions.clearLegacy(c)
        AppLock.remove(c)
        PageBlock.disable(c)
        Admin.dpm(c).clearDeviceOwnerApp(c.packageName)
        LockStore.clearUnlock(c)
        LockStore.clearUpdateWindow(c)

        // Read-back: sach me hata?
        return if (DnsState.isOwner(c)) fail(LockResult.Reason.STILL_OWNER) else LockResult.Ok()
    }
}
