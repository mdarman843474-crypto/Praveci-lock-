package com.pindnslock

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Settings ka "Additional settings" page pehchanna (sirf English Xiaomi Settings).
 * Is page par rows hoti hain jaise Accessibility, Developer options, Date & time.
 * Main Settings page par bhi "Additional settings" ek row hai, par wahan Wi-Fi / Bluetooth ki rows hoti hain,
 * isliye wo page nahi maana jata (nahi to poori Settings band ho jati).
 */
object AdditionalSettingsPage {
    fun isShownIn(root: AccessibilityNodeInfo): Boolean {
        // Tez filter: page par "Additional settings" likha hota hai
        if (root.findAccessibilityNodeInfosByText("Additional settings").isNullOrEmpty()) return false
        if (PageText.isSearchScreen(root)) return false
        if (onMainSettings(root)) return false
        return PageText.hasExact(root, "Additional settings") &&
            (PageText.hasExact(root, "Accessibility") ||
                PageText.hasExact(root, "Developer options") ||
                PageText.hasExact(root, "Date & time"))
    }

    private fun onMainSettings(root: AccessibilityNodeInfo): Boolean =
        PageText.hasExact(root, "Wi-Fi") || PageText.hasExact(root, "WLAN") || PageText.hasExact(root, "Bluetooth")

    /** Debug ke liye: kaun si sharten sach thin. */
    fun verdict(root: AccessibilityNodeInfo): String =
        "title=" + PageText.hasExact(root, "Additional settings") + " search=" + PageText.isSearchScreen(root) +
            " mainSettings=" + onMainSettings(root) + " accessibility=" + PageText.hasExact(root, "Accessibility") +
            " developer=" + PageText.hasExact(root, "Developer options") + " dateTime=" + PageText.hasExact(root, "Date & time") +
            " => page=" + isShownIn(root)
}
