package com.pindnslock

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

/** Device Owner (DevicePolicyManager) tak pahunchne ke chhote helpers. */
object Admin {
    fun dpm(c: Context) = c.getSystemService(DevicePolicyManager::class.java)

    fun component(c: Context) = ComponentName(c, AdminReceiver::class.java)
}
