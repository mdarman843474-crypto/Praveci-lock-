package com.pindnslock

import android.view.accessibility.AccessibilityNodeInfo

/** Accessibility node tree me text dhoondhne ke chhote helpers (page pehchanne ke liye). */
object PageText {
    private const val EDIT_TEXT = "android.widget.EditText"

    /** Poora text label ke barabar wala node hai? (findAccessibilityNodeInfosByText sirf "contains" dekhta hai) */
    fun hasExact(root: AccessibilityNodeInfo, label: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(label) ?: return false
        return nodes.any { it.text?.toString() == label || it.contentDescription?.toString() == label }
    }

    fun hasEditText(root: AccessibilityNodeInfo): Boolean = hasEditText(root, 0)

    /** Koi EditText jiska hint ya text needle (chhote akshar me) rakhta hai? */
    fun hasHintContaining(root: AccessibilityNodeInfo, needle: String): Boolean = hintSearch(root, needle.lowercase(), 0)

    private fun hintSearch(node: AccessibilityNodeInfo?, needle: String, depth: Int): Boolean {
        if (node == null || depth > 25) return false
        if (node.className?.toString() == EDIT_TEXT) {
            val hint = node.hintText?.toString()?.lowercase() ?: ""
            val text = node.text?.toString()?.lowercase() ?: ""
            if (hint.contains(needle) || text.contains(needle)) return true
        }
        for (i in 0 until node.childCount) {
            if (hintSearch(node.getChild(i), needle, depth + 1)) return true
        }
        return false
    }

    /** Search screen: wahan search box (EditText) aur Cancel hota hai. Search results me page ke naam aa sakte hain, par wo page nahi. */
    fun isSearchScreen(root: AccessibilityNodeInfo): Boolean = hasEditText(root) || hasExact(root, "Cancel")

    /** Debug ke liye: window ke text nodes (zyada se zyada 60). */
    fun describe(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        collect(root, sb, 0, IntArray(1))
        return sb.toString()
    }

    private fun collect(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int, count: IntArray) {
        if (node == null || depth > 25 || count[0] >= 60) return
        val t = node.text?.toString()
        val d = node.contentDescription?.toString()
        val cls = node.className?.toString() ?: ""
        if (!t.isNullOrEmpty() || !d.isNullOrEmpty() || cls == EDIT_TEXT) {
            count[0]++
            sb.append(depth).append(' ').append(cls.substringAfterLast('.')).append(": ").append(t ?: "")
            if (!d.isNullOrEmpty()) sb.append(" [").append(d).append(']')
            sb.append('\n')
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), sb, depth + 1, count)
    }

    private fun hasEditText(node: AccessibilityNodeInfo?, depth: Int): Boolean {
        if (node == null || depth > 25) return false
        if (node.className?.toString() == EDIT_TEXT) return true
        for (i in 0 until node.childCount) {
            if (hasEditText(node.getChild(i), depth + 1)) return true
        }
        return false
    }
}
