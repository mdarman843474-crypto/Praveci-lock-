package com.pindnslock

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Settings ka "Private DNS" page pehchanna (sirf English Settings).
 * Xiaomi ke page par rows hoti hain: Off, Automatic, "Private DNS provider hostname" (aur hostname chuna ho to "Custom name").
 * Search screen par bhi inme se naam aa sakte hain, par wahan search box (EditText) aur Cancel hota hai, isliye wo page nahi maana jata.
 */
object PrivateDnsPage {
    fun isShownIn(root: AccessibilityNodeInfo): Boolean {
        // Tez filter: is page par "Private DNS provider hostname" naam ki row hoti hai
        if (root.findAccessibilityNodeInfosByText("Private DNS provider hostname").isNullOrEmpty()) return false
        if (PageText.isSearchScreen(root)) return false
        return PageText.hasExact(root, "Automatic") && PageText.hasExact(root, "Off")
    }

    /** Debug ke liye: kaun si sharten sach thin. */
    fun verdict(root: AccessibilityNodeInfo): String {
        val provider = !root.findAccessibilityNodeInfosByText("Private DNS provider hostname").isNullOrEmpty()
        return "provider=" + provider + " editText=" + PageText.hasEditText(root) + " cancel=" + PageText.hasExact(root, "Cancel") +
            " automatic=" + PageText.hasExact(root, "Automatic") + " off=" + PageText.hasExact(root, "Off") + " => page=" + isShownIn(root)
    }
}
