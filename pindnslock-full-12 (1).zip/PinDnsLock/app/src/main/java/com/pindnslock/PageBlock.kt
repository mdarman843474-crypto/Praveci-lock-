package com.pindnslock

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityManager

/**
 * "Private DNS page band" wali Accessibility service (PageBlockService) ko ON rakhna aur chalta rakhna.
 * ON / restart karne ke liye WRITE_SECURE_SETTINGS chahiye (adb se ek baar). Permission na ho to
 * Settings → Accessibility me khud ON karna padta hai.
 *
 * "Not working" tab dikhta hai jab service ka process crash / kill ho jaye: Android use khud dobara nahi chalata,
 * isliye ensure() use OFF → ON karke dobara chalu karta hai.
 */
object PageBlock {
    private const val PREFS = "page_block"
    private const val RESTART_GAP_MS = 60_000L

    private fun me(c: Context) = ComponentName(c, PageBlockService::class.java)

    private fun entries(c: Context): List<String> =
        (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .split(':')
            .filter { it.isNotBlank() }

    private fun isMe(c: Context, entry: String): Boolean = ComponentName.unflattenFromString(entry) == me(c)

    private fun write(c: Context, list: List<String>) {
        Settings.Secure.putString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, list.joinToString(":"))
    }

    /** Settings me ON hai? (chal rahi ho ya nahi, ye alag baat hai) */
    fun isEnabled(c: Context): Boolean {
        val on = Settings.Secure.getInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
        return on && entries(c).any { isMe(c, it) }
    }

    /** Android ne service ko sach me chalu (bound) kar rakha hai? */
    fun isRunning(c: Context): Boolean {
        val am = c.getSystemService(AccessibilityManager::class.java)
        val list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK) ?: return false
        return list.any {
            val si = it.resolveInfo?.serviceInfo
            si != null && si.packageName == c.packageName && si.name == PageBlockService::class.java.name
        }
    }

    fun state(c: Context): PageBlockState = when {
        !isEnabled(c) -> PageBlockState.OFF
        isRunning(c) -> PageBlockState.RUNNING
        else -> PageBlockState.ENABLED_NOT_RUNNING
    }

    /**
     * Band ho to ON karo; ON ho par chal na rahi ho to OFF → ON karke dobara chalao (60 second me ek baar se zyada nahi).
     * Permission na ho to kuch nahi kar sakte, sirf haal batata hai. Blocking - background thread se chalao.
     */
    fun ensure(c: Context): PageBlockState {
        if (!DnsWriter.canWriteDirect(c)) return state(c)
        when (state(c)) {
            PageBlockState.RUNNING -> {}
            PageBlockState.OFF -> enable(c)
            PageBlockState.ENABLED_NOT_RUNNING -> if (restartAllowed(c)) restart(c)
        }
        return state(c)
    }

    private fun enable(c: Context) {
        runCatching {
            val list = entries(c).toMutableList()
            if (list.none { isMe(c, it) }) list.add(me(c).flattenToString())
            write(c, list)
            Settings.Secure.putInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        }
    }

    private fun restart(c: Context) {
        runCatching {
            val without = entries(c).filter { !isMe(c, it) }
            write(c, without)
            Thread.sleep(500L) // Android ko service band karne ka time do
            write(c, without + me(c).flattenToString())
            Settings.Secure.putInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        }
    }

    private fun restartAllowed(c: Context): Boolean {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - p.getLong("restartAt", 0L) < RESTART_GAP_MS) return false
        p.edit().putLong("restartAt", now).apply()
        return true
    }

    /** "Device Owner hatao" par: service ko list se nikaal do (permission ho tab). */
    fun disable(c: Context) {
        if (!DnsWriter.canWriteDirect(c)) return
        runCatching { write(c, entries(c).filter { !isMe(c, it) }) }
    }
}
