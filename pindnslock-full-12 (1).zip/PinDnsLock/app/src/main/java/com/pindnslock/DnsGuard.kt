package com.pindnslock

import android.app.admin.DevicePolicyManager
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.provider.Settings

/**
 * Private DNS ki nigrani.
 *
 * Android ki rok (DISALLOW_CONFIG_PRIVATE_DNS) sirf Settings ka normal rasta band karti hai. Xiaomi Settings ki
 * search ka shortcut jaise raaste us rok ko bypass kar sakte hain. Isliye lock laga hone par, jaise hi Private DNS
 * badalta hai, ye saved host wapas laga deta hai (unlock ke 10 minute me kuch nahi badalta).
 * Android ka host check fail ho to DnsWriter adb se mili permission se seedha likhta hai.
 * Accessibility ki setting badalne par bhi chalta hai, taaki Private DNS page rokne wali service band na rahe.
 *
 *  - JOB_TRIGGER : Private DNS ki setting badalte hi chalta hai. Ek baar chal ke khatam hota hai, isliye har baar
 *                  dobara lagana padta hai, aur reboot ke baad nahi bachta.
 *  - JOB_PERIODIC: har 15 minute, reboot ke baad bhi bachta hai, aur trigger job wapas lagata hai.
 * Dono RelockJobService chalata hai.
 */
object DnsGuard {
    const val JOB_PERIODIC = 4102
    const val JOB_TRIGGER = 4103
    private const val PERIOD_MS = 15 * 60_000L

    private fun scheduler(c: Context) = c.getSystemService(JobScheduler::class.java)
    private fun service(c: Context) = ComponentName(c, RelockJobService::class.java)

    /** Nigrani wala job abhi register hai? */
    fun isArmed(c: Context): Boolean = scheduler(c).getPendingJob(JOB_TRIGGER) != null

    /** Turant wapas lagane wali chalti service (DnsFastGuardService) chal rahi hai? */
    fun isFastRunning(): Boolean = DnsFastGuardService.running

    /** Chalti service shuru karo (sirf Device Owner ho tab). Kabhi exception nahi fenkta. */
    private fun startFast(c: Context) {
        if (DnsState.isOwner(c)) DnsFastGuardService.start(c)
    }

    /** Jo job nahi hai use lagao, aur turant wapas lagane wali service shuru karo. Kabhi exception nahi fenkta. */
    fun ensureScheduled(c: Context) {
        schedule(c, replaceTrigger = false)
        startFast(c)
    }

    /** UI thread se bhi chala sakte ho: kaam alag thread par hota hai. */
    fun kick(c: Context) {
        val app = c.applicationContext
        startFast(app) // UI (foreground) se shuru karna sabse pakka hai
        Thread {
            try {
                runOnce(app)
            } catch (e: Exception) {
                // agli baar (app khulne par / 15 minute baad) phir try hoga
            }
        }.start()
    }

    /** Ek chakkar: zarurat ho to Private DNS wapas lagao, phir nigrani wala job dobara register karo. Background thread se chalao. */
    fun runOnce(c: Context) {
        try {
            enforce(c)
        } finally {
            schedule(c, replaceTrigger = true)
            startFast(c)
        }
    }

    /**
     * Lock laga ho aur Private DNS saved host se alag ho to saved host wapas lagao.
     * Blocking (Android host ka network check karta hai) - background thread se chalao.
     * true = sab theek (ya kuch karna nahi tha), false = wapas nahi laga paye (jaise host is network par jawab nahi de raha).
     */
    fun enforce(c: Context): Boolean {
        // Unlock window me ya Device Owner na ho to kuch nahi badalte
        if (!DnsState.isOwner(c) || !DnsState.isLocked(c)) return true

        PageBlock.ensure(c) // Private DNS page rokne wali service band ya "Not working" ho to wapas chalu

        val host = LockStore.savedHost(c)
        if (DnsState.isHostActive(c, host)) return true

        val hs = DnsWriter.setHost(c, host)
        return hs.code == DevicePolicyManager.PRIVATE_DNS_SET_NO_ERROR && DnsState.isHostActive(c, host)
    }

    fun cancel(c: Context) {
        val js = scheduler(c)
        js.cancel(JOB_PERIODIC)
        js.cancel(JOB_TRIGGER)
        DnsFastGuardService.stop(c)
    }

    private fun schedule(c: Context, replaceTrigger: Boolean) {
        if (!DnsState.isOwner(c)) return
        val js = scheduler(c)
        try {
            if (js.getPendingJob(JOB_PERIODIC) == null) js.schedule(periodicJob(c))
            // replaceTrigger = chal rahe job ke andar se naya lagana (same id purane ki jagah leta hai)
            if (replaceTrigger || js.getPendingJob(JOB_TRIGGER) == null) js.schedule(triggerJob(c))
        } catch (e: Exception) {
            // Job na lage to app crash nahi karti; agli baar app khulne par dobara try hoga
        }
    }

    private fun periodicJob(c: Context) =
        JobInfo.Builder(JOB_PERIODIC, service(c))
            .setPeriodic(PERIOD_MS)
            .setPersisted(true)
            .build()

    private fun triggerJob(c: Context) =
        JobInfo.Builder(JOB_TRIGGER, service(c))
            .addTriggerContentUri(watch("private_dns_mode"))
            .addTriggerContentUri(watch("private_dns_specifier"))
            .addTriggerContentUri(watchSecure(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES))
            .addTriggerContentUri(watchSecure(Settings.Secure.ACCESSIBILITY_ENABLED))
            .setTriggerContentUpdateDelay(500L)
            .setTriggerContentMaxDelay(5_000L)
            .build()

    private fun watchSecure(setting: String) =
        JobInfo.TriggerContentUri(
            Settings.Secure.getUriFor(setting),
            JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS
        )

    private fun watch(setting: String) =
        JobInfo.TriggerContentUri(
            Settings.Global.getUriFor(setting),
            JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS
        )
}
