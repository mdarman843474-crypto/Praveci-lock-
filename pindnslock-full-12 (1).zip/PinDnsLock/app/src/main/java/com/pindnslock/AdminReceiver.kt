package com.pindnslock

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
