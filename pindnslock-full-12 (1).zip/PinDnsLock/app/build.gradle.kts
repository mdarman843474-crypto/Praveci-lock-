plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pindnslock"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pindnslock"
        minSdk = 29
        targetSdk = 34
        // Har build ka versionCode pichhle se bada (minute ginti), taaki naya APK hamesha "update" maana jaye
        versionCode = (System.currentTimeMillis() / 60_000L).toInt()
        versionName = "1.3"
    }

    // Fixed debug key (keystore/debug.jks) so every build has the SAME signature
    signingConfigs {
        getByName("debug") {
            val ks = rootProject.file("keystore/debug.jks")
            if (ks.exists()) {
                storeFile = ks
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
